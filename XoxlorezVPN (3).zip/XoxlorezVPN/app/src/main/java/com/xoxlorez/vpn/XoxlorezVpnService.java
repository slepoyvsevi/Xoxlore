package com.xoxlorez.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class XoxlorezVpnService extends VpnService {
    private static final String TAG = "XoxlorezVpnService";
    private static final String CHANNEL_ID = "xoxlorez_vpn";
    private static final int NOTIFICATION_ID = 1001;

    public static final String ACTION_CONNECT = "com.xoxlorez.vpn.CONNECT";
    public static final String ACTION_DISCONNECT = "com.xoxlorez.vpn.DISCONNECT";
    public static final String ACTION_STATUS = "com.xoxlorez.vpn.STATUS";
    public static final String EXTRA_SERVER = "server_config";
    public static final String STATUS_CONNECTED = "CONNECTED";
    public static final String STATUS_DISCONNECTED = "DISCONNECTED";
    public static final String STATUS_CONNECTING = "CONNECTING";
    public static final String STATUS_ERROR = "ERROR";
    public static final String EXTRA_STATUS = "status";

    private Thread vpnThread;
    private ParcelFileDescriptor vpnInterface;
    private volatile boolean running = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_CONNECT.equals(action)) {
            ServerConfig server = (ServerConfig) intent.getSerializableExtra(EXTRA_SERVER);
            connect(server);
        } else if (ACTION_DISCONNECT.equals(action)) {
            disconnect();
        }
        return START_STICKY;
    }

    private void connect(final ServerConfig server) {
        sendStatus(STATUS_CONNECTING);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Подключение..."));

        vpnThread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Builder builder = new Builder();
                    builder.setSession("XOXLOREZ VPN");
                    builder.addAddress("10.8.0.2", 24);
                    builder.addRoute("0.0.0.0", 0);
                    builder.addDnsServer("8.8.8.8");
                    builder.addDnsServer("1.1.1.1");
                    builder.setMtu(1500);

                    vpnInterface = builder.establish();
                    if (vpnInterface == null) {
                        sendStatus(STATUS_ERROR);
                        return;
                    }

                    running = true;
                    sendStatus(STATUS_CONNECTED);
                    String region = (server != null && server.getCountry() != null)
                            ? server.getCountry() : "VPN";
                    startForeground(NOTIFICATION_ID, buildNotification("Подключено — " + region));

                    FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
                    ByteBuffer packet = ByteBuffer.allocate(32767);

                    while (running) {
                        packet.clear();
                        int length = in.read(packet.array());
                        if (length <= 0) {
                            Thread.sleep(10);
                        }
                    }

                } catch (InterruptedException e) {
                    Log.d(TAG, "VPN thread interrupted");
                } catch (Exception e) {
                    Log.e(TAG, "VPN error", e);
                    sendStatus(STATUS_ERROR);
                } finally {
                    cleanup();
                }
            }
        });
        vpnThread.start();
    }

    private void disconnect() {
        running = false;
        if (vpnThread != null) vpnThread.interrupt();
        cleanup();
        sendStatus(STATUS_DISCONNECTED);
        stopForeground(true);
        stopSelf();
    }

    private void cleanup() {
        try {
            if (vpnInterface != null) {
                vpnInterface.close();
                vpnInterface = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Cleanup error", e);
        }
    }

    private void sendStatus(String status) {
        Intent intent = new Intent(ACTION_STATUS);
        intent.putExtra(EXTRA_STATUS, status);
        sendBroadcast(intent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "XOXLOREZ VPN", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent, flags);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("XOXLOREZ VPN")
                    .setContentText(text)
                    .setSmallIcon(R.drawable.ic_vpn_key)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
        } else {
            return new Notification.Builder(this)
                    .setContentTitle("XOXLOREZ VPN")
                    .setContentText(text)
                    .setSmallIcon(R.drawable.ic_vpn_key)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
        }
    }

    @Override
    public void onDestroy() {
        disconnect();
        super.onDestroy();
    }
}
