package com.xoxlorez.vpn;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.net.InetSocketAddress;
import java.net.Socket;

public class PingService extends Service {
    private static final String TAG = "PingService";
    public static final String ACTION_PING_COMPLETE = "com.xoxlorez.vpn.PING_COMPLETE";
    public static final String ACTION_PING_PROGRESS = "com.xoxlorez.vpn.PING_PROGRESS";
    public static final String EXTRA_PROGRESS = "progress";
    public static final String EXTRA_TOTAL = "total";

    @Override
    public IBinder onBind(Intent intent) { return null; }

    public static int measurePing(String host, int port) {
        if (host == null || host.isEmpty()) return -1;
        try {
            long start = System.currentTimeMillis();
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(host, port > 0 ? port : 443), 3000);
            socket.close();
            return (int)(System.currentTimeMillis() - start);
        } catch (Exception e) {
            Log.d(TAG, "Ping failed: " + host + ":" + port);
            return -1;
        }
    }
}
