package com.xoxlorez.vpn;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import java.util.ArrayList;
import java.util.List;

public class RegionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ServerAdapter adapter;
    private List<ServerConfig> allServers;
    private List<ServerConfig> filteredServers;
    private ConfigManager configManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_region);

        configManager = ConfigManager.getInstance(this);
        allServers = configManager.getServers();
        filteredServers = new ArrayList<ServerConfig>(allServers);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_servers);
        EditText etSearch = (EditText) findViewById(R.id.et_search);
        TextView tvCount = (TextView) findViewById(R.id.tv_server_count);
        View btnBack = findViewById(R.id.btn_back);

        if (tvCount != null) tvCount.setText(allServers.size() + " серверов");

        if (btnBack != null) btnBack.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { finish(); }
        });

        adapter = new ServerAdapter(filteredServers,
                configManager.getSelectedServerId(),
                new ServerAdapter.OnServerClickListener() {
                    public void onServerClick(ServerConfig server) {
                        Intent result = new Intent();
                        result.putExtra("selected_server_id", server.getId());
                        setResult(RESULT_OK, result);
                        finish();
                    }
                });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    filterServers(s.toString());
                }
                public void afterTextChanged(Editable s) {}
            });
        }
    }

    private void filterServers(String query) {
        filteredServers.clear();
        if (query == null || query.isEmpty()) {
            filteredServers.addAll(allServers);
        } else {
            String q = query.toLowerCase();
            for (int i = 0; i < allServers.size(); i++) {
                ServerConfig s = allServers.get(i);
                String country = s.getCountry() != null ? s.getCountry().toLowerCase() : "";
                String host = s.getHost() != null ? s.getHost().toLowerCase() : "";
                String name = s.getName() != null ? s.getName().toLowerCase() : "";
                if (country.contains(q) || host.contains(q) || name.contains(q)) {
                    filteredServers.add(s);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }
}
