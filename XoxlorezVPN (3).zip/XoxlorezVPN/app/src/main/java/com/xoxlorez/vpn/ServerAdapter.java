package com.xoxlorez.vpn;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import java.util.List;

public class ServerAdapter extends RecyclerView.Adapter<ServerAdapter.ViewHolder> {

    public interface OnServerClickListener {
        void onServerClick(ServerConfig server);
    }

    private List<ServerConfig> servers;
    private String selectedId;
    private final OnServerClickListener listener;

    public ServerAdapter(List<ServerConfig> servers, String selectedId, OnServerClickListener listener) {
        this.servers = servers;
        this.selectedId = selectedId;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_server, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final ServerConfig server = servers.get(position);
        boolean selected = selectedId != null && selectedId.equals(server.getId());
        holder.bind(server, selected);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                selectedId = server.getId();
                notifyDataSetChanged();
                listener.onServerClick(server);
            }
        });
    }

    @Override
    public int getItemCount() { return servers.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvFlag, tvName, tvPing, tvProtocol;
        View indicator;

        ViewHolder(View itemView) {
            super(itemView);
            tvFlag = (TextView) itemView.findViewById(R.id.tv_server_flag);
            tvName = (TextView) itemView.findViewById(R.id.tv_server_name);
            tvPing = (TextView) itemView.findViewById(R.id.tv_server_ping);
            tvProtocol = (TextView) itemView.findViewById(R.id.tv_server_protocol);
            indicator = itemView.findViewById(R.id.view_selected_indicator);
        }

        void bind(ServerConfig server, boolean selected) {
            tvFlag.setText(server.getFlagEmoji() != null ? server.getFlagEmoji() : "🌐");

            String name = server.getCountry();
            if (name == null || name.equals("Unknown")) name = server.getHost();
            tvName.setText(name != null ? name : "Server");

            int ping = server.getPing();
            tvPing.setText(ping >= 0 ? ping + " ms" : "-- ms");

            if (ping < 0) tvPing.setTextColor(0xFF888888);
            else if (ping < 100) tvPing.setTextColor(0xFF00FF88);
            else if (ping < 300) tvPing.setTextColor(0xFFFFAA00);
            else tvPing.setTextColor(0xFFFF4444);

            if (tvProtocol != null) {
                String proto = server.getProtocol() != null ? server.getProtocol().name() : "VLESS";
                tvProtocol.setText(proto);
            }

            itemView.setBackgroundColor(selected ? 0x337B2FFF : 0x00000000);
            if (indicator != null) indicator.setVisibility(selected ? View.VISIBLE : View.INVISIBLE);
        }
    }
}
