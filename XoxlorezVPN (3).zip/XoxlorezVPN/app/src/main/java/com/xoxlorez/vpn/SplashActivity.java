package com.xoxlorez.vpn;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import java.util.List;

public class SplashActivity extends AppCompatActivity {

    private TextView tvStatus;
    private ProgressBar progressBar;
    private TextView tvProgress;
    private boolean finished = false;
    private final Handler mainHandler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvStatus = (TextView) findViewById(R.id.tv_splash_status);
        progressBar = (ProgressBar) findViewById(R.id.progress_splash);
        tvProgress = (TextView) findViewById(R.id.tv_splash_progress);

        final ConfigManager cm = ConfigManager.getInstance(this);

        if (cm.isFirstRun()) {
            tvStatus.setText("Проверяем серверы...");
            progressBar.setVisibility(View.VISIBLE);
            tvProgress.setVisibility(View.VISIBLE);
            startPingCheck(cm);
        } else {
            tvStatus.setText("Добро пожаловать!");
            mainHandler.postDelayed(new Runnable() {
                public void run() { goToMain(); }
            }, 1200);
        }
    }

    private void startPingCheck(final ConfigManager cm) {
        cm.loadServers();
        final List<ServerConfig> servers = cm.getServers();
        final int total = servers.size();
        progressBar.setMax(total > 0 ? total : 1);

        new Thread(new Runnable() {
            public void run() {
                for (int i = 0; i < servers.size(); i++) {
                    ServerConfig s = servers.get(i);
                    int ping = PingService.measurePing(s.getHost(), s.getPort());
                    s.setPing(ping);
                    s.setOnline(ping >= 0);
                    final int progress = i + 1;
                    mainHandler.post(new Runnable() {
                        public void run() {
                            progressBar.setProgress(progress);
                            tvProgress.setText(progress + " / " + total);
                            int pct = total > 0 ? progress * 100 / total : 0;
                            tvStatus.setText("Проверяем... " + pct + "%");
                        }
                    });
                }
                cm.saveServerPings(servers);
                cm.setFirstRunDone();
                mainHandler.post(new Runnable() {
                    public void run() { goToMain(); }
                });
            }
        }).start();

        // Fallback timeout
        mainHandler.postDelayed(new Runnable() {
            public void run() {
                cm.setFirstRunDone();
                goToMain();
            }
        }, 30000);
    }

    private void goToMain() {
        if (finished) return;
        finished = true;
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
