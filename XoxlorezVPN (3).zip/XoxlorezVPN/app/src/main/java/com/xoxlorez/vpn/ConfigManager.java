package com.xoxlorez.vpn;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ConfigManager {
    private static final String TAG = "ConfigManager";
    private static final String PREFS_NAME = "xoxlorez_prefs";
    private static final String KEY_SERVERS = "cached_servers";
    private static final String KEY_SELECTED = "selected_server_id";
    private static final String KEY_FIRST_RUN = "first_run";
    private static final String KEY_THEME = "app_theme";

    private static final String[] CONFIG_FILES = {
            "configs/BYPASS",
            "configs/CUSTOM",
            "configs/STR",
            "configs/STR.BYPASS",
            "configs/Vless"
    };

    private static ConfigManager instance;
    private final Context context;
    private final SharedPreferences prefs;
    private final Gson gson = new Gson();
    private List<ServerConfig> servers = new ArrayList<>();

    private ConfigManager(Context ctx) {
        this.context = ctx.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static synchronized ConfigManager getInstance(Context ctx) {
        if (instance == null) instance = new ConfigManager(ctx);
        return instance;
    }

    public boolean isFirstRun() {
        return prefs.getBoolean(KEY_FIRST_RUN, true);
    }

    public void setFirstRunDone() {
        prefs.edit().putBoolean(KEY_FIRST_RUN, false).apply();
    }

    public List<ServerConfig> loadServers() {
        List<ServerConfig> all = new ArrayList<>();
        for (String file : CONFIG_FILES) {
            try {
                InputStream is = context.getAssets().open(file);
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append("\n");
                reader.close();
                List<ServerConfig> parsed = ConfigParser.parseMultiLine(sb.toString());
                all.addAll(parsed);
                Log.d(TAG, "Loaded " + parsed.size() + " from " + file);
            } catch (Exception e) {
                Log.e(TAG, "Error loading " + file, e);
            }
        }
        this.servers = all;
        return all;
    }

    public List<ServerConfig> getServers() {
        if (servers.isEmpty()) loadServers();
        return servers;
    }

    public void saveServerPings(List<ServerConfig> updated) {
        this.servers = updated;
        String json = gson.toJson(updated);
        prefs.edit().putString(KEY_SERVERS, json).apply();
    }

    public void setSelectedServer(String id) {
        prefs.edit().putString(KEY_SELECTED, id).apply();
    }

    public String getSelectedServerId() {
        return prefs.getString(KEY_SELECTED, null);
    }

    public ServerConfig getSelectedServer() {
        String id = getSelectedServerId();
        List<ServerConfig> list = getServers();
        if (list.isEmpty()) return null;
        if (id == null) return list.get(0);
        for (ServerConfig s : list) {
            if (id.equals(s.getId())) return s;
        }
        return list.get(0);
    }

    public int getTheme() { return prefs.getInt(KEY_THEME, 0); }
    public void setTheme(int theme) { prefs.edit().putInt(KEY_THEME, theme).apply(); }
}
