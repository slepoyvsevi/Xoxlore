package com.xoxlorez.vpn;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int VPN_REQUEST_CODE = 100;
    private static final int REGION_REQUEST_CODE = 101;

    private View btnConnect;
    private TextView tvConnectLabel, tvStatus, tvRegionFlag, tvRegionName, tvUptime;
    private View pulseRing1, pulseRing2;
    private View panelMain, panelSettings, panelTheme;
    private TextView tabVpn, tabSettings, tabTheme;
    private View btnRegionPicker, btnCheckServers;

    private boolean isConnected = false;
    private boolean isConnecting = false;
    private ServerConfig selectedServer;
    private long connectStartTime = 0;
    private final Handler uptimeHandler = new Handler();
    private Runnable uptimeRunnable;
    private ConfigManager configManager;

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String status = intent.getStringExtra(XoxlorezVpnService.EXTRA_STATUS);
            if (status == null) return;
            runOnUiThread(new Runnable() {
                public void run() {
                    if (XoxlorezVpnService.STATUS_CONNECTED.equals(status)) onVpnConnected();
                    else if (XoxlorezVpnService.STATUS_DISCONNECTED.equals(status)) onVpnDisconnected();
                    else if (XoxlorezVpnService.STATUS_CONNECTING.equals(status)) onVpnConnecting();
                    else if (XoxlorezVpnService.STATUS_ERROR.equals(status)) onVpnError();
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configManager = ConfigManager.getInstance(this);
        selectedServer = configManager.getSelectedServer();
        initViews();
        setupTabs();
        updateRegionDisplay();
        startGlitch();
        registerReceiver(vpnReceiver, new IntentFilter(XoxlorezVpnService.ACTION_STATUS));
    }

    private void initViews() {
        btnConnect = findViewById(R.id.btn_connect);
        tvConnectLabel = (TextView) findViewById(R.id.tv_connect_label);
        tvStatus = (TextView) findViewById(R.id.tv_status);
        tvRegionFlag = (TextView) findViewById(R.id.tv_region_flag);
        tvRegionName = (TextView) findViewById(R.id.tv_region_name);
        tvUptime = (TextView) findViewById(R.id.tv_uptime);
        pulseRing1 = findViewById(R.id.pulse_ring_1);
        pulseRing2 = findViewById(R.id.pulse_ring_2);
        panelMain = findViewById(R.id.panel_main);
        panelSettings = findViewById(R.id.panel_settings);
        panelTheme = findViewById(R.id.panel_theme);
        tabVpn = (TextView) findViewById(R.id.tab_vpn);
        tabSettings = (TextView) findViewById(R.id.tab_settings);
        tabTheme = (TextView) findViewById(R.id.tab_theme);
        btnRegionPicker = findViewById(R.id.btn_region_picker);
        btnCheckServers = findViewById(R.id.btn_check_servers);

        btnConnect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { onConnectClicked(); }
        });
        btnRegionPicker.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { openRegionPicker(); }
        });
        btnCheckServers.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { checkServers(); }
        });

        View btnThemeCyber = findViewById(R.id.btn_theme_cyber);
        View btnThemeDark = findViewById(R.id.btn_theme_dark);
        View btnThemeNeon = findViewById(R.id.btn_theme_neon);

        if (btnThemeCyber != null) btnThemeCyber.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { configManager.setTheme(0); recreate(); }
        });
        if (btnThemeDark != null) btnThemeDark.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { configManager.setTheme(1); recreate(); }
        });
        if (btnThemeNeon != null) btnThemeNeon.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { configManager.setTheme(2); recreate(); }
        });
    }

    private void startGlitch() {
        final Handler h = new Handler();
        final String[] variants = {"XOXLOREZ VPN", "X0XL0REZ VPN", "XOXLOREZ VPN", "X0XL0R3Z VPN"};
        final int[] idx = {0};
        final TextView tvTitle = (TextView) findViewById(R.id.tv_title);
        if (tvTitle == null) return;
        h.postDelayed(new Runnable() {
            public void run() {
                tvTitle.setText(variants[idx[0] % variants.length]);
                idx[0]++;
                h.postDelayed(this, idx[0] % 6 == 0 ? 3000 : 80);
            }
        }, 2000);
    }

    private void setupTabs() {
        tabVpn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showPanel(0); }
        });
        tabSettings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showPanel(1); }
        });
        tabTheme.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { showPanel(2); }
        });
        showPanel(0);
    }

    private void showPanel(int index) {
        panelMain.setVisibility(index == 0 ? View.VISIBLE : View.GONE);
        panelSettings.setVisibility(index == 1 ? View.VISIBLE : View.GONE);
        panelTheme.setVisibility(index == 2 ? View.VISIBLE : View.GONE);
        tabVpn.setTextColor(index == 0 ? 0xFF7B2FFF : 0xFF6B6B8A);
        tabSettings.setTextColor(index == 1 ? 0xFF7B2FFF : 0xFF6B6B8A);
        tabTheme.setTextColor(index == 2 ? 0xFF7B2FFF : 0xFF6B6B8A);
        tabVpn.setBackgroundColor(index == 0 ? 0xFF1A0A30 : 0xFF12121A);
        tabSettings.setBackgroundColor(index == 1 ? 0xFF1A0A30 : 0xFF12121A);
        tabTheme.setBackgroundColor(index == 2 ? 0xFF1A0A30 : 0xFF12121A);
    }

    private void onConnectClicked() {
        if (isConnecting) return;
        if (isConnected) disconnectVpn();
        else connectVpn();
    }

    private void connectVpn() {
        Intent permIntent = VpnService.prepare(this);
        if (permIntent != null) startActivityForResult(permIntent, VPN_REQUEST_CODE);
        else startVpnService();
    }

    private void startVpnService() {
        isConnecting = true;
        onVpnConnecting();
        Intent intent = new Intent(this, XoxlorezVpnService.class);
        intent.setAction(XoxlorezVpnService.ACTION_CONNECT);
        intent.putExtra(XoxlorezVpnService.EXTRA_SERVER, selectedServer);
        startService(intent);
    }

    private void disconnectVpn() {
        Intent intent = new Intent(this, XoxlorezVpnService.class);
        intent.setAction(XoxlorezVpnService.ACTION_DISCONNECT);
        startService(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startVpnService();
        } else if (requestCode == REGION_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            String serverId = data.getStringExtra("selected_server_id");
            if (serverId != null) {
                configManager.setSelectedServer(serverId);
                selectedServer = configManager.getSelectedServer();
                updateRegionDisplay();
            }
        }
    }

    private void onVpnConnecting() {
        tvStatus.setText("CONNECTING...");
        tvStatus.setTextColor(0xFFFFAA00);
        tvConnectLabel.setText("CANCEL");
        pulseRing1.setVisibility(View.VISIBLE);
        pulseRing2.setVisibility(View.VISIBLE);
    }

    private void onVpnConnected() {
        isConnecting = false;
        isConnected = true;
        tvStatus.setText("CONNECTED");
        tvStatus.setTextColor(0xFF00FF88);
        tvConnectLabel.setText("DISCONNECT");
        connectStartTime = SystemClock.elapsedRealtime();
        startUptimeTimer();
        pulseRing1.setVisibility(View.VISIBLE);
        pulseRing2.setVisibility(View.VISIBLE);
    }

    private void onVpnDisconnected() {
        isConnecting = false;
        isConnected = false;
        tvStatus.setText("DISCONNECTED");
        tvStatus.setTextColor(0xFF7B2FFF);
        tvConnectLabel.setText("CONNECT");
        tvUptime.setText("00:00:00");
        stopUptimeTimer();
        pulseRing1.setVisibility(View.INVISIBLE);
        pulseRing2.setVisibility(View.INVISIBLE);
    }

    private void onVpnError() {
        isConnecting = false;
        isConnected = false;
        tvStatus.setText("ERROR");
        tvStatus.setTextColor(0xFFFF3333);
        tvConnectLabel.setText("CONNECT");
        pulseRing1.setVisibility(View.INVISIBLE);
        pulseRing2.setVisibility(View.INVISIBLE);
        stopUptimeTimer();
    }

    private void startUptimeTimer() {
        uptimeRunnable = new Runnable() {
            public void run() {
                if (!isConnected) return;
                long elapsed = SystemClock.elapsedRealtime() - connectStartTime;
                long h = elapsed / 3600000;
                long m = (elapsed % 3600000) / 60000;
                long s = (elapsed % 60000) / 1000;
                tvUptime.setText(String.format("%02d:%02d:%02d", h, m, s));
                uptimeHandler.postDelayed(this, 1000);
            }
        };
        uptimeHandler.post(uptimeRunnable);
    }

    private void stopUptimeTimer() {
        if (uptimeRunnable != null) uptimeHandler.removeCallbacks(uptimeRunnable);
    }

    private void updateRegionDisplay() {
        if (selectedServer == null) {
            tvRegionFlag.setText("🌐");
            tvRegionName.setText("Auto");
            return;
        }
        String flag = selectedServer.getFlagEmoji();
        tvRegionFlag.setText(flag != null ? flag : "🌐");
        String country = selectedServer.getCountry();
        tvRegionName.setText(country != null && !country.equals("Unknown") ? country : selectedServer.getHost());
    }

    private void openRegionPicker() {
        startActivityForResult(new Intent(this, RegionActivity.class), REGION_REQUEST_CODE);
    }

    private void checkServers() {
        final TextView btn = (TextView) btnCheckServers;
        btn.setText("Проверяем...");
        btnCheckServers.setEnabled(false);
        new Thread(new Runnable() {
            public void run() {
                configManager.loadServers();
                List<ServerConfig> list = configManager.getServers();
                for (int i = 0; i < list.size(); i++) {
                    ServerConfig s = list.get(i);
                    int ping = PingService.measurePing(s.getHost(), s.getPort());
                    s.setPing(ping);
                    s.setOnline(ping >= 0);
                }
                configManager.saveServerPings(list);
                runOnUiThread(new Runnable() {
                    public void run() {
                        btn.setText("Проверить серверы");
                        btnCheckServers.setEnabled(true);
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(vpnReceiver); } catch (Exception ignored) {}
        stopUptimeTimer();
        super.onDestroy();
    }
}
