package com.xoxlorez.vpn.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.xoxlorez.vpn.R;
import com.xoxlorez.vpn.model.ServerConfig;
import com.xoxlorez.vpn.service.XoxlorezVpnService;
import com.xoxlorez.vpn.utils.ConfigManager;

public class MainActivity extends AppCompatActivity {

    private static final int VPN_REQUEST_CODE = 100;
    private static final int REGION_REQUEST_CODE = 101;

    // Views
    private View btnConnect;
    private TextView tvConnectLabel;
    private TextView tvStatus;
    private TextView tvRegionFlag;
    private TextView tvRegionName;
    private TextView tvUptime;
    private View pulseRing1, pulseRing2;
    private BottomNavigationView bottomNav;

    // Panels
    private View panelMain, panelSettings, panelTheme;
    private View btnRegionPicker;
    private View btnCheckServers;
    private View[] themeButtons;

    // State
    private boolean isConnected = false;
    private boolean isConnecting = false;
    private ServerConfig selectedServer;
    private long connectStartTime = 0;
    private Handler uptimeHandler = new Handler();
    private Runnable uptimeRunnable;
    private ObjectAnimator pulseAnim1, pulseAnim2;
    private ConfigManager configManager;

    private BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String status = intent.getStringExtra(XoxlorezVpnService.EXTRA_STATUS);
            if (status == null) return;
            runOnUiThread(() -> {
                switch (status) {
                    case XoxlorezVpnService.STATUS_CONNECTED:
                        onVpnConnected();
                        break;
                    case XoxlorezVpnService.STATUS_DISCONNECTED:
                        onVpnDisconnected();
                        break;
                    case XoxlorezVpnService.STATUS_CONNECTING:
                        onVpnConnecting();
                        break;
                    case XoxlorezVpnService.STATUS_ERROR:
                        onVpnError();
                        break;
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        configManager = ConfigManager.getInstance(this);
        selectedServer = configManager.getSelectedServer();

        initViews();
        setupBottomNav();
        setupGlitchTitle();
        updateRegionDisplay();
        setupPulseAnimations();
        setupThemeButtons();

        IntentFilter filter = new IntentFilter(XoxlorezVpnService.ACTION_STATUS);
        registerReceiver(vpnReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    private void initViews() {
        btnConnect = findViewById(R.id.btn_connect);
        tvConnectLabel = findViewById(R.id.tv_connect_label);
        tvStatus = findViewById(R.id.tv_status);
        tvRegionFlag = findViewById(R.id.tv_region_flag);
        tvRegionName = findViewById(R.id.tv_region_name);
        tvUptime = findViewById(R.id.tv_uptime);
        pulseRing1 = findViewById(R.id.pulse_ring_1);
        pulseRing2 = findViewById(R.id.pulse_ring_2);
        bottomNav = findViewById(R.id.bottom_nav);
        panelMain = findViewById(R.id.panel_main);
        panelSettings = findViewById(R.id.panel_settings);
        panelTheme = findViewById(R.id.panel_theme);
        btnRegionPicker = findViewById(R.id.btn_region_picker);
        btnCheckServers = findViewById(R.id.btn_check_servers);

        btnConnect.setOnClickListener(v -> onConnectClicked());
        btnRegionPicker.setOnClickListener(v -> openRegionPicker());
        btnCheckServers.setOnClickListener(v -> checkServers());
    }

    private void setupBottomNav() {
        bottomNav.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_connect) {
                showPanel(panelMain);
            } else if (id == R.id.nav_settings) {
                showPanel(panelSettings);
            } else if (id == R.id.nav_theme) {
                showPanel(panelTheme);
            }
            return true;
        });
    }

    private void showPanel(View panel) {
        panelMain.setVisibility(View.GONE);
        panelSettings.setVisibility(View.GONE);
        panelTheme.setVisibility(View.GONE);
        panel.setVisibility(View.VISIBLE);
        panel.setAlpha(0f);
        panel.animate().alpha(1f).setDuration(300).start();
    }

    private void setupGlitchTitle() {
        TextView title = findViewById(R.id.tv_title);
        if (title == null) return;
        Handler h = new Handler();
        final String[] glitchChars = {"X0XL0R3Z VPN", "X0XL0REZ VPN", "XOXLOREZ VPN", "X̷O̷X̷L̷O̷R̷E̷Z̷ VPN"};
        final int[] idx = {0};
        Runnable glitch = new Runnable() {
            @Override
            public void run() {
                title.setText(glitchChars[idx[0] % glitchChars.length]);
                idx[0]++;
                h.postDelayed(this, idx[0] % 5 == 0 ? 3000 : 80);
            }
        };
        h.post(glitch);
    }

    private void setupPulseAnimations() {
        pulseAnim1 = createPulseAnimator(pulseRing1, 0);
        pulseAnim2 = createPulseAnimator(pulseRing2, 500);
    }

    private ObjectAnimator createPulseAnimator(View view, int delay) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "alpha", 0.7f, 0f);
        anim.setDuration(1500);
        anim.setStartDelay(delay);
        anim.setRepeatCount(ObjectAnimator.INFINITE);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        return anim;
    }

    private void startPulse() {
        pulseRing1.setVisibility(View.VISIBLE);
        pulseRing2.setVisibility(View.VISIBLE);
        pulseAnim1.start();
        pulseAnim2.start();

        // Scale pulse rings
        pulseRing1.animate().scaleX(1.5f).scaleY(1.5f).setDuration(1500)
                .withEndAction(() -> pulseRing1.setScaleX(1f)).start();
    }

    private void stopPulse() {
        pulseAnim1.cancel();
        pulseAnim2.cancel();
        pulseRing1.setVisibility(View.INVISIBLE);
        pulseRing2.setVisibility(View.INVISIBLE);
    }

    private void onConnectClicked() {
        if (isConnecting) return;
        if (isConnected) {
            disconnectVpn();
        } else {
            connectVpn();
        }
    }

    private void connectVpn() {
        Intent permIntent = VpnService.prepare(this);
        if (permIntent != null) {
            startActivityForResult(permIntent, VPN_REQUEST_CODE);
        } else {
            startVpnService();
        }
    }

    private void startVpnService() {
        isConnecting = true;
        onVpnConnecting();

        Intent intent = new Intent(this, XoxlorezVpnService.class);
        intent.setAction(XoxlorezVpnService.ACTION_CONNECT);
        intent.putExtra(XoxlorezVpnService.EXTRA_SERVER, selectedServer);
        startService(intent);
    }

    private void disconnectVpn() {
        Intent intent = new Intent(this, XoxlorezVpnService.class);
        intent.setAction(XoxlorezVpnService.ACTION_DISCONNECT);
        startService(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startVpnService();
        } else if (requestCode == REGION_REQUEST_CODE && resultCode == Activity.RESULT_OK && data != null) {
            String serverId = data.getStringExtra("selected_server_id");
            if (serverId != null) {
                configManager.setSelectedServer(serverId);
                selectedServer = configManager.getSelectedServer();
                updateRegionDisplay();
            }
        }
    }

    private void onVpnConnecting() {
        isConnecting = true;
        isConnected = false;
        tvStatus.setText("CONNECTING...");
        tvStatus.setTextColor(0xFFFFAA00);
        tvConnectLabel.setText("CANCEL");
        btnConnect.setBackgroundTintList(null);
        startPulse();
    }

    private void onVpnConnected() {
        isConnecting = false;
        isConnected = true;
        tvStatus.setText("CONNECTED");
        tvStatus.setTextColor(0xFF00FF88);
        tvConnectLabel.setText("DISCONNECT");
        connectStartTime = SystemClock.elapsedRealtime();
        startUptimeTimer();
        startPulse();
    }

    private void onVpnDisconnected() {
        isConnecting = false;
        isConnected = false;
        tvStatus.setText("DISCONNECTED");
        tvStatus.setTextColor(0xFF7B2FFF);
        tvConnectLabel.setText("CONNECT");
        tvUptime.setText("00:00:00");
        stopUptimeTimer();
        stopPulse();
    }

    private void onVpnError() {
        isConnecting = false;
        isConnected = false;
        tvStatus.setText("ERROR");
        tvStatus.setTextColor(0xFFFF3333);
        tvConnectLabel.setText("CONNECT");
        stopPulse();
        stopUptimeTimer();
    }

    private void startUptimeTimer() {
        uptimeRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isConnected) return;
                long elapsed = SystemClock.elapsedRealtime() - connectStartTime;
                long h = elapsed / 3600000;
                long m = (elapsed % 3600000) / 60000;
                long s = (elapsed % 60000) / 1000;
                tvUptime.setText(String.format("%02d:%02d:%02d", h, m, s));
                uptimeHandler.postDelayed(this, 1000);
            }
        };
        uptimeHandler.post(uptimeRunnable);
    }

    private void stopUptimeTimer() {
        if (uptimeRunnable != null) uptimeHandler.removeCallbacks(uptimeRunnable);
    }

    private void updateRegionDisplay() {
        if (selectedServer == null) {
            tvRegionFlag.setText("🌐");
            tvRegionName.setText("Auto");
            return;
        }
        tvRegionFlag.setText(selectedServer.getFlagEmoji() != null ? selectedServer.getFlagEmoji() : "🌐");
        String country = selectedServer.getCountry();
        tvRegionName.setText(country != null && !country.equals("Unknown") ? country : selectedServer.getHost());
    }

    private void openRegionPicker() {
        Intent intent = new Intent(this, RegionActivity.class);
        startActivityForResult(intent, REGION_REQUEST_CODE);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
    }

    private void checkServers() {
        btnCheckServers.setEnabled(false);
        ((TextView) btnCheckServers).setText("Проверяем...");

        Intent serviceIntent = new Intent(this, com.xoxlorez.vpn.service.PingService.class);
        startService(serviceIntent);

        com.xoxlorez.vpn.service.PingService pingService = new com.xoxlorez.vpn.service.PingService();
        new Thread(() -> {
            configManager.loadServers();
            configManager.getServers().parallelStream().forEach(server -> {
                int ping = com.xoxlorez.vpn.service.PingService.measurePing(server.getHost(), server.getPort());
                server.setPing(ping);
                server.setOnline(ping >= 0);
            });
            configManager.saveServerPings(configManager.getServers());
            runOnUiThread(() -> {
                btnCheckServers.setEnabled(true);
                ((TextView) btnCheckServers).setText("Проверить серверы");
            });
        }).start();
    }

    private void setupThemeButtons() {
        View btnCyber = findViewById(R.id.btn_theme_cyber);
        View btnDark = findViewById(R.id.btn_theme_dark);
        View btnNeon = findViewById(R.id.btn_theme_neon);

        if (btnCyber != null) btnCyber.setOnClickListener(v -> applyTheme(0));
        if (btnDark != null) btnDark.setOnClickListener(v -> applyTheme(1));
        if (btnNeon != null) btnNeon.setOnClickListener(v -> applyTheme(2));
    }

    private void applyTheme(int theme) {
        configManager.setTheme(theme);
        recreate();
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(vpnReceiver); } catch (Exception ignored) {}
        stopUptimeTimer();
        super.onDestroy();
    }
}
