package com.xoxlorez.vpn.model;

import java.io.Serializable;

public class ServerConfig implements Serializable {
    public enum Protocol { VLESS, VMESS, SS, TROJAN, WIREGUARD, UNKNOWN }

    private String rawUri;
    private String id;
    private String host;
    private int port;
    private Protocol protocol;
    private String name;
    private String country;
    private String countryCode;
    private String flagEmoji;
    private int ping = -1;
    private boolean online = false;

    // VLESS/VMess specific
    private String uuid;
    private String security;
    private String network;
    private String path;
    private String sni;
    private String pbk;
    private String sid;
    private String flow;
    private String fp;
    private String headerType;
    private String hostHeader;

    // SS specific
    private String method;
    private String password;

    public ServerConfig() {}

    public String getRawUri() { return rawUri; }
    public void setRawUri(String rawUri) { this.rawUri = rawUri; }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getHost() { return host; }
    public void setHost(String host) { this.host = host; }

    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }

    public Protocol getProtocol() { return protocol; }
    public void setProtocol(Protocol protocol) { this.protocol = protocol; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getCountryCode() { return countryCode; }
    public void setCountryCode(String countryCode) { this.countryCode = countryCode; }

    public String getFlagEmoji() { return flagEmoji; }
    public void setFlagEmoji(String flagEmoji) { this.flagEmoji = flagEmoji; }

    public int getPing() { return ping; }
    public void setPing(int ping) { this.ping = ping; }

    public boolean isOnline() { return online; }
    public void setOnline(boolean online) { this.online = online; }

    public String getUuid() { return uuid; }
    public void setUuid(String uuid) { this.uuid = uuid; }

    public String getSecurity() { return security; }
    public void setSecurity(String security) { this.security = security; }

    public String getNetwork() { return network; }
    public void setNetwork(String network) { this.network = network; }

    public String getPath() { return path; }
    public void setPath(String path) { this.path = path; }

    public String getSni() { return sni; }
    public void setSni(String sni) { this.sni = sni; }

    public String getPbk() { return pbk; }
    public void setPbk(String pbk) { this.pbk = pbk; }

    public String getSid() { return sid; }
    public void setSid(String sid) { this.sid = sid; }

    public String getFlow() { return flow; }
    public void setFlow(String flow) { this.flow = flow; }

    public String getFp() { return fp; }
    public void setFp(String fp) { this.fp = fp; }

    public String getHeaderType() { return headerType; }
    public void setHeaderType(String headerType) { this.headerType = headerType; }

    public String getHostHeader() { return hostHeader; }
    public void setHostHeader(String hostHeader) { this.hostHeader = hostHeader; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getDisplayName() {
        if (name != null && !name.isEmpty() && !name.equals("none")) return name;
        return (flagEmoji != null ? flagEmoji + " " : "") + host;
    }

    public String getPingDisplay() {
        if (ping < 0) return "-- ms";
        return ping + " ms";
    }
}
