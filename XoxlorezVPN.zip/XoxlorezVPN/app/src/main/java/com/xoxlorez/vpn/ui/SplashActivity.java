package com.xoxlorez.vpn.ui;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.xoxlorez.vpn.R;
import com.xoxlorez.vpn.service.PingService;
import com.xoxlorez.vpn.utils.ConfigManager;

public class SplashActivity extends AppCompatActivity {

    private TextView tvStatus;
    private ProgressBar progressBar;
    private TextView tvProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvStatus = findViewById(R.id.tv_splash_status);
        progressBar = findViewById(R.id.progress_splash);
        tvProgress = findViewById(R.id.tv_splash_progress);

        animateLogo();

        ConfigManager cm = ConfigManager.getInstance(this);

        if (cm.isFirstRun()) {
            tvStatus.setText("Проверяем серверы...");
            progressBar.setVisibility(View.VISIBLE);
            tvProgress.setVisibility(View.VISIBLE);
            loadAndPing(cm);
        } else {
            tvStatus.setText("Добро пожаловать!");
            new Handler().postDelayed(() -> goToMain(), 1500);
        }
    }

    private void loadAndPing(ConfigManager cm) {
        cm.loadServers();

        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (PingService.ACTION_PING_PROGRESS.equals(action)) {
                    int progress = intent.getIntExtra(PingService.EXTRA_PROGRESS, 0);
                    int total = intent.getIntExtra(PingService.EXTRA_TOTAL, 1);
                    runOnUiThread(() -> {
                        progressBar.setMax(total);
                        progressBar.setProgress(progress);
                        tvProgress.setText(progress + " / " + total);
                        tvStatus.setText("Проверяем серверы... " + (progress * 100 / total) + "%");
                    });
                } else if (PingService.ACTION_PING_COMPLETE.equals(action)) {
                    unregisterReceiver(this);
                    cm.setFirstRunDone();
                    runOnUiThread(() -> goToMain());
                }
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(PingService.ACTION_PING_PROGRESS);
        filter.addAction(PingService.ACTION_PING_COMPLETE);
        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);

        Intent serviceIntent = new Intent(this, PingService.class);
        startService(serviceIntent);

        new Handler().postDelayed(() -> {
            PingService ps = new PingService();
            ps.pingAll(null);
        }, 100);

        // Fallback timeout
        new Handler().postDelayed(() -> {
            cm.setFirstRunDone();
            goToMain();
        }, 30000);
    }

    private void animateLogo() {
        View logo = findViewById(R.id.tv_splash_logo);
        if (logo == null) return;
        logo.setAlpha(0f);
        logo.setScaleX(0.7f);
        logo.setScaleY(0.7f);

        ObjectAnimator alpha = ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f);
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(logo, "scaleX", 0.7f, 1f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(logo, "scaleY", 0.7f, 1f);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(alpha, scaleX, scaleY);
        set.setDuration(800);
        set.setInterpolator(new AccelerateDecelerateInterpolator());
        set.start();
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }
}
