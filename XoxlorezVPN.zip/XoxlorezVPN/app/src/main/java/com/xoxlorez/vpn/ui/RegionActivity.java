package com.xoxlorez.vpn.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.xoxlorez.vpn.R;
import com.xoxlorez.vpn.model.ServerConfig;
import com.xoxlorez.vpn.utils.ConfigManager;

import java.util.ArrayList;
import java.util.List;

public class RegionActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ServerAdapter adapter;
    private EditText etSearch;
    private List<ServerConfig> allServers;
    private List<ServerConfig> filteredServers;
    private ConfigManager configManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_region);

        configManager = ConfigManager.getInstance(this);
        allServers = configManager.getServers();
        filteredServers = new ArrayList<>(allServers);

        recyclerView = findViewById(R.id.recycler_servers);
        etSearch = findViewById(R.id.et_search);
        View btnBack = findViewById(R.id.btn_back);

        if (btnBack != null) btnBack.setOnClickListener(v -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        adapter = new ServerAdapter(filteredServers,
                configManager.getSelectedServerId(),
                server -> {
                    Intent result = new Intent();
                    result.putExtra("selected_server_id", server.getId());
                    setResult(RESULT_OK, result);
                    finish();
                    overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterServers(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        TextView tvCount = findViewById(R.id.tv_server_count);
        if (tvCount != null) tvCount.setText(allServers.size() + " серверов");
    }

    private void filterServers(String query) {
        filteredServers.clear();
        if (query.isEmpty()) {
            filteredServers.addAll(allServers);
        } else {
            String q = query.toLowerCase();
            for (ServerConfig s : allServers) {
                String country = s.getCountry() != null ? s.getCountry().toLowerCase() : "";
                String host = s.getHost() != null ? s.getHost().toLowerCase() : "";
                String name = s.getName() != null ? s.getName().toLowerCase() : "";
                if (country.contains(q) || host.contains(q) || name.contains(q)) {
                    filteredServers.add(s);
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
    }
}
