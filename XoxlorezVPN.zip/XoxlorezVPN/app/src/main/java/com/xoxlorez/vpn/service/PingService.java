package com.xoxlorez.vpn.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;

import com.xoxlorez.vpn.model.ServerConfig;
import com.xoxlorez.vpn.utils.ConfigManager;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class PingService extends Service {
    private static final String TAG = "PingService";
    public static final String ACTION_PING_COMPLETE = "com.xoxlorez.vpn.PING_COMPLETE";
    public static final String ACTION_PING_PROGRESS = "com.xoxlorez.vpn.PING_PROGRESS";
    public static final String EXTRA_PROGRESS = "progress";
    public static final String EXTRA_TOTAL = "total";

    private final IBinder binder = new LocalBinder();
    private ExecutorService executor;

    public class LocalBinder extends Binder {
        public PingService getService() { return PingService.this; }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newFixedThreadPool(10);
    }

    @Override
    public void onDestroy() {
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }

    public void pingAll(Runnable onComplete) {
        List<ServerConfig> servers = ConfigManager.getInstance(this).getServers();
        if (servers.isEmpty()) {
            if (onComplete != null) onComplete.run();
            return;
        }

        AtomicInteger done = new AtomicInteger(0);
        int total = servers.size();
        Handler mainHandler = new Handler(Looper.getMainLooper());

        for (ServerConfig server : servers) {
            executor.submit(() -> {
                int ping = measurePing(server.getHost(), server.getPort());
                server.setPing(ping);
                server.setOnline(ping >= 0);

                int progress = done.incrementAndGet();
                mainHandler.post(() -> {
                    Intent progressIntent = new Intent(ACTION_PING_PROGRESS);
                    progressIntent.putExtra(EXTRA_PROGRESS, progress);
                    progressIntent.putExtra(EXTRA_TOTAL, total);
                    sendBroadcast(progressIntent);

                    if (progress >= total) {
                        ConfigManager.getInstance(PingService.this).saveServerPings(servers);
                        sendBroadcast(new Intent(ACTION_PING_COMPLETE));
                        if (onComplete != null) onComplete.run();
                    }
                });
            });
        }
    }

    public static int measurePing(String host, int port) {
        try {
            long start = System.currentTimeMillis();
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress(host, port), 3000);
            socket.close();
            long elapsed = System.currentTimeMillis() - start;
            return (int) elapsed;
        } catch (Exception e) {
            Log.d(TAG, "Ping failed for " + host + ":" + port);
            return -1;
        }
    }
}
