package com.xoxlorez.vpn.parser;

import android.util.Base64;
import android.util.Log;

import com.xoxlorez.vpn.model.ServerConfig;

import org.json.JSONObject;

import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ConfigParser {

    private static final String TAG = "ConfigParser";

    public static List<ServerConfig> parseMultiLine(String content) {
        List<ServerConfig> list = new ArrayList<>();
        String[] lines = content.split("[\\r\\n]+");
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty()) continue;
            ServerConfig cfg = parseSingleUri(line);
            if (cfg != null) list.add(cfg);
        }
        return list;
    }

    public static ServerConfig parseSingleUri(String uri) {
        try {
            if (uri.startsWith("vless://")) return parseVless(uri);
            if (uri.startsWith("vmess://")) return parseVmess(uri);
            if (uri.startsWith("ss://")) return parseSS(uri);
            if (uri.startsWith("trojan://")) return parseTrojan(uri);
            if (uri.startsWith("wireguard://")) return parseWireguard(uri);
        } catch (Exception e) {
            Log.w(TAG, "Failed to parse: " + uri.substring(0, Math.min(50, uri.length())), e);
        }
        return null;
    }

    private static ServerConfig parseVless(String uri) throws Exception {
        ServerConfig cfg = new ServerConfig();
        cfg.setRawUri(uri);
        cfg.setProtocol(ServerConfig.Protocol.VLESS);
        cfg.setId(UUID.randomUUID().toString());

        // vless://uuid@host:port?params#name
        String withoutScheme = uri.substring("vless://".length());
        int hashIdx = withoutScheme.lastIndexOf('#');
        String fragment = "";
        if (hashIdx >= 0) {
            fragment = URLDecoder.decode(withoutScheme.substring(hashIdx + 1), "UTF-8");
            withoutScheme = withoutScheme.substring(0, hashIdx);
        }

        int atIdx = withoutScheme.indexOf('@');
        if (atIdx < 0) return null;

        cfg.setUuid(withoutScheme.substring(0, atIdx));

        String hostPart = withoutScheme.substring(atIdx + 1);
        int queryIdx = hostPart.indexOf('?');
        String params = "";
        if (queryIdx >= 0) {
            params = hostPart.substring(queryIdx + 1);
            hostPart = hostPart.substring(0, queryIdx);
        }

        int colonIdx = hostPart.lastIndexOf(':');
        if (colonIdx >= 0) {
            cfg.setHost(hostPart.substring(0, colonIdx));
            try { cfg.setPort(Integer.parseInt(hostPart.substring(colonIdx + 1))); } catch (Exception ignored) {}
        } else {
            cfg.setHost(hostPart);
        }

        Map<String, String> p = parseQuery(params);
        cfg.setSecurity(p.getOrDefault("security", "none"));
        cfg.setNetwork(p.getOrDefault("type", "tcp"));
        cfg.setPath(p.getOrDefault("path", "/"));
        cfg.setSni(p.getOrDefault("sni", ""));
        cfg.setPbk(p.getOrDefault("pbk", ""));
        cfg.setSid(p.getOrDefault("sid", ""));
        cfg.setFlow(p.getOrDefault("flow", ""));
        cfg.setFp(p.getOrDefault("fp", ""));
        cfg.setHeaderType(p.getOrDefault("headerType", ""));
        cfg.setHostHeader(p.getOrDefault("host", ""));

        parseNameAndFlag(cfg, fragment);
        return cfg;
    }

    private static ServerConfig parseVmess(String uri) throws Exception {
        ServerConfig cfg = new ServerConfig();
        cfg.setRawUri(uri);
        cfg.setProtocol(ServerConfig.Protocol.VMESS);
        cfg.setId(UUID.randomUUID().toString());

        String b64 = uri.substring("vmess://".length());
        int hashIdx = b64.indexOf('#');
        String fragment = "";
        String jsonStr = "";

        if (hashIdx >= 0) {
            // Non-standard format: vmess://uuid@host:port?params#name
            // Try to parse as VLESS-style
            String withoutScheme = uri.substring("vmess://".length());
            fragment = URLDecoder.decode(withoutScheme.substring(hashIdx + 1), "UTF-8");
            withoutScheme = withoutScheme.substring(0, hashIdx);

            int atIdx = withoutScheme.indexOf('@');
            int qIdx = withoutScheme.indexOf('?');
            String params = qIdx >= 0 ? withoutScheme.substring(qIdx + 1) : "";
            String hostPort = atIdx >= 0 ? withoutScheme.substring(atIdx + 1, qIdx >= 0 ? qIdx : withoutScheme.length()) : "";

            if (atIdx >= 0) cfg.setUuid(withoutScheme.substring(0, atIdx));

            int colonIdx = hostPort.lastIndexOf(':');
            if (colonIdx >= 0) {
                cfg.setHost(hostPort.substring(0, colonIdx));
                try { cfg.setPort(Integer.parseInt(hostPort.substring(colonIdx + 1))); } catch (Exception ignored) {}
            }

            Map<String, String> p = parseQuery(params);
            cfg.setNetwork(p.getOrDefault("type", "tcp"));
            cfg.setSecurity(p.getOrDefault("security", "none"));
            cfg.setSni(p.getOrDefault("sni", ""));
            cfg.setPath(p.getOrDefault("path", "/"));
        } else {
            // Standard base64 vmess
            try {
                byte[] decoded = Base64.decode(b64, Base64.DEFAULT | Base64.NO_PADDING | Base64.NO_WRAP);
                jsonStr = new String(decoded);
                JSONObject obj = new JSONObject(jsonStr);
                cfg.setHost(obj.optString("add", ""));
                cfg.setPort(obj.optInt("port", 443));
                cfg.setUuid(obj.optString("id", ""));
                cfg.setNetwork(obj.optString("net", "tcp"));
                cfg.setPath(obj.optString("path", "/"));
                cfg.setSni(obj.optString("sni", ""));
                cfg.setHostHeader(obj.optString("host", ""));
                String tls = obj.optString("tls", "");
                cfg.setSecurity(tls.isEmpty() ? "none" : tls);
                String name = obj.optString("ps", "");
                parseNameAndFlag(cfg, name);
            } catch (Exception e) {
                Log.w(TAG, "VMess base64 decode failed: " + e.getMessage());
            }
        }

        if (fragment != null && !fragment.isEmpty() && (cfg.getName() == null || cfg.getName().isEmpty())) {
            parseNameAndFlag(cfg, fragment);
        }

        return cfg;
    }

    private static ServerConfig parseSS(String uri) throws Exception {
        ServerConfig cfg = new ServerConfig();
        cfg.setRawUri(uri);
        cfg.setProtocol(ServerConfig.Protocol.SS);
        cfg.setId(UUID.randomUUID().toString());

        String withoutScheme = uri.substring("ss://".length());
        int hashIdx = withoutScheme.lastIndexOf('#');
        String fragment = "";
        if (hashIdx >= 0) {
            fragment = URLDecoder.decode(withoutScheme.substring(hashIdx + 1), "UTF-8");
            withoutScheme = withoutScheme.substring(0, hashIdx);
        }

        // Try base64 userinfo@host:port
        int atIdx = withoutScheme.lastIndexOf('@');
        String userInfo = "";
        String hostPort = withoutScheme;

        if (atIdx >= 0) {
            userInfo = withoutScheme.substring(0, atIdx);
            hostPort = withoutScheme.substring(atIdx + 1);
        }

        // Decode userInfo
        try {
            String decoded = new String(Base64.decode(userInfo, Base64.DEFAULT | Base64.NO_PADDING | Base64.NO_WRAP));
            int colonIdx = decoded.indexOf(':');
            if (colonIdx >= 0) {
                cfg.setMethod(decoded.substring(0, colonIdx));
                cfg.setPassword(decoded.substring(colonIdx + 1));
            }
        } catch (Exception e) {
            // Maybe it's method:password directly
            int colonIdx = userInfo.indexOf(':');
            if (colonIdx >= 0) {
                cfg.setMethod(URLDecoder.decode(userInfo.substring(0, colonIdx), "UTF-8"));
                cfg.setPassword(URLDecoder.decode(userInfo.substring(colonIdx + 1), "UTF-8"));
            }
        }

        int colonIdx = hostPort.lastIndexOf(':');
        if (colonIdx >= 0) {
            cfg.setHost(hostPort.substring(0, colonIdx));
            try { cfg.setPort(Integer.parseInt(hostPort.substring(colonIdx + 1))); } catch (Exception ignored) {}
        } else {
            cfg.setHost(hostPort);
        }

        parseNameAndFlag(cfg, fragment);
        return cfg;
    }

    private static ServerConfig parseTrojan(String uri) throws Exception {
        ServerConfig cfg = new ServerConfig();
        cfg.setRawUri(uri);
        cfg.setProtocol(ServerConfig.Protocol.TROJAN);
        cfg.setId(UUID.randomUUID().toString());

        String withoutScheme = uri.substring("trojan://".length());
        int hashIdx = withoutScheme.lastIndexOf('#');
        String fragment = "";
        if (hashIdx >= 0) {
            fragment = URLDecoder.decode(withoutScheme.substring(hashIdx + 1), "UTF-8");
            withoutScheme = withoutScheme.substring(0, hashIdx);
        }

        int qIdx = withoutScheme.indexOf('?');
        String params = "";
        if (qIdx >= 0) {
            params = withoutScheme.substring(qIdx + 1);
            withoutScheme = withoutScheme.substring(0, qIdx);
        }

        int atIdx = withoutScheme.lastIndexOf('@');
        String password = atIdx >= 0 ? withoutScheme.substring(0, atIdx) : "";
        String hostPort = atIdx >= 0 ? withoutScheme.substring(atIdx + 1) : withoutScheme;
        cfg.setPassword(URLDecoder.decode(password, "UTF-8"));

        int colonIdx = hostPort.lastIndexOf(':');
        if (colonIdx >= 0) {
            cfg.setHost(hostPort.substring(0, colonIdx));
            try { cfg.setPort(Integer.parseInt(hostPort.substring(colonIdx + 1))); } catch (Exception ignored) {}
        } else {
            cfg.setHost(hostPort);
        }

        Map<String, String> p = parseQuery(params);
        cfg.setSni(p.getOrDefault("sni", ""));
        cfg.setNetwork(p.getOrDefault("type", "tcp"));
        cfg.setSecurity(p.getOrDefault("security", "tls"));

        parseNameAndFlag(cfg, fragment);
        return cfg;
    }

    private static ServerConfig parseWireguard(String uri) throws Exception {
        ServerConfig cfg = new ServerConfig();
        cfg.setRawUri(uri);
        cfg.setProtocol(ServerConfig.Protocol.WIREGUARD);
        cfg.setId(UUID.randomUUID().toString());

        int hashIdx = uri.lastIndexOf('#');
        String fragment = "";
        String body = uri.substring("wireguard://".length());
        if (hashIdx >= 0) {
            fragment = URLDecoder.decode(uri.substring(hashIdx + 1), "UTF-8");
            body = body.substring(0, hashIdx - "wireguard://".length());
        }

        int atIdx = body.lastIndexOf('@');
        String hostPort = atIdx >= 0 ? body.substring(atIdx + 1) : body;
        int qIdx = hostPort.indexOf('?');
        if (qIdx >= 0) hostPort = hostPort.substring(0, qIdx);

        int colonIdx = hostPort.lastIndexOf(':');
        if (colonIdx >= 0) {
            cfg.setHost(hostPort.substring(0, colonIdx));
            try { cfg.setPort(Integer.parseInt(hostPort.substring(colonIdx + 1))); } catch (Exception ignored) {}
        } else {
            cfg.setHost(hostPort);
        }

        parseNameAndFlag(cfg, fragment);
        return cfg;
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) return map;
        String[] parts = query.split("&");
        for (String part : parts) {
            int eq = part.indexOf('=');
            if (eq >= 0) {
                try {
                    String key = URLDecoder.decode(part.substring(0, eq), "UTF-8");
                    String val = URLDecoder.decode(part.substring(eq + 1), "UTF-8");
                    map.put(key, val);
                } catch (Exception ignored) {}
            }
        }
        return map;
    }

    private static void parseNameAndFlag(ServerConfig cfg, String fragment) {
        if (fragment == null || fragment.isEmpty()) {
            cfg.setName(cfg.getHost() != null ? cfg.getHost() : "Unknown");
            cfg.setCountry("Unknown");
            cfg.setFlagEmoji("🌐");
            return;
        }

        // Extract flag emoji (regional indicator symbols)
        StringBuilder flagBuilder = new StringBuilder();
        StringBuilder nameBuilder = new StringBuilder();
        boolean flagDone = false;
        int i = 0;
        while (i < fragment.length()) {
            int cp = fragment.codePointAt(i);
            int charCount = Character.charCount(cp);
            // Regional indicator symbols: U+1F1E6 to U+1F1FF
            if (!flagDone && cp >= 0x1F1E6 && cp <= 0x1F1FF) {
                flagBuilder.appendCodePoint(cp);
            } else {
                flagDone = true;
                nameBuilder.appendCodePoint(cp);
            }
            i += charCount;
        }

        String flag = flagBuilder.toString();
        String namePart = nameBuilder.toString().trim();
        // Remove channel/telegram prefixes
        namePart = namePart.replaceAll("@\\w+", "").trim();
        namePart = namePart.replaceAll("^\\s*[|\\-–]\\s*", "").trim();

        cfg.setFlagEmoji(flag.isEmpty() ? "🌐" : flag);
        cfg.setName(namePart.isEmpty() ? (cfg.getHost() != null ? cfg.getHost() : "Server") : namePart);

        // Detect country from fragment text
        cfg.setCountry(detectCountry(fragment));
        cfg.setCountryCode(detectCountryCode(flag));
    }

    private static String detectCountry(String text) {
        text = text.toLowerCase();
        if (text.contains("russia") || text.contains("ru ") || text.contains("🇷🇺")) return "Russia";
        if (text.contains("netherlands") || text.contains("nl ") || text.contains("🇳🇱")) return "Netherlands";
        if (text.contains("germany") || text.contains("de ") || text.contains("🇩🇪")) return "Germany";
        if (text.contains("france") || text.contains("fr ") || text.contains("🇫🇷")) return "France";
        if (text.contains("finland") || text.contains("🇫🇮")) return "Finland";
        if (text.contains("japan") || text.contains("tokyo") || text.contains("🇯🇵")) return "Japan";
        if (text.contains("united kingdom") || text.contains("uk ") || text.contains("🇬🇧")) return "UK";
        if (text.contains("united states") || text.contains("us ") || text.contains("🇺🇸")) return "USA";
        if (text.contains("singapore") || text.contains("sg ") || text.contains("🇸🇬")) return "Singapore";
        if (text.contains("canada") || text.contains("ca ") || text.contains("🇨🇦")) return "Canada";
        if (text.contains("austria") || text.contains("🇦🇹")) return "Austria";
        if (text.contains("latvia") || text.contains("riga") || text.contains("🇱🇻")) return "Latvia";
        if (text.contains("poland") || text.contains("warsaw") || text.contains("🇵🇱")) return "Poland";
        if (text.contains("sweden") || text.contains("se ") || text.contains("🇸🇪")) return "Sweden";
        if (text.contains("luxembourg") || text.contains("lu ") || text.contains("🇱🇺")) return "Luxembourg";
        if (text.contains("australia") || text.contains("au ") || text.contains("🇦🇺")) return "Australia";
        if (text.contains("spain") || text.contains("es ") || text.contains("🇪🇸")) return "Spain";
        if (text.contains("jordan") || text.contains("jo ") || text.contains("🇯🇴")) return "Jordan";
        if (text.contains("hong kong") || text.contains("hk ") || text.contains("🇭🇰")) return "Hong Kong";
        if (text.contains("vietnam") || text.contains("🇻🇳")) return "Vietnam";
        if (text.contains("kazakhstan") || text.contains("kz ") || text.contains("🇰🇿")) return "Kazakhstan";
        return "Unknown";
    }

    private static String detectCountryCode(String flag) {
        if (flag == null || flag.length() < 4) return "XX";
        // Regional indicator: subtract 0x1F1E6, add 'A'
        try {
            int cp1 = flag.codePointAt(0);
            int cp2 = flag.codePointAt(2);
            char c1 = (char)('A' + (cp1 - 0x1F1E6));
            char c2 = (char)('A' + (cp2 - 0x1F1E6));
            return "" + c1 + c2;
        } catch (Exception e) {
            return "XX";
        }
    }
}
