# Add project specific ProGuard rules here.
-keep class com.xoxlorez.vpn.model.** { *; }
-keep class com.xoxlorez.vpn.service.** { *; }
-keepclassmembers class com.xoxlorez.vpn.model.ServerConfig { *; }
