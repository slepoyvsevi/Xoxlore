# XOXLOREZ VPN — Android App

## Структура проекта
```
XoxlorezVPN/
├── app/
│   ├── src/main/
│   │   ├── java/com/xoxlorez/vpn/
│   │   │   ├── model/ServerConfig.java       — модель сервера
│   │   │   ├── parser/ConfigParser.java      — парсер VLESS/VMess/SS/Trojan/WG
│   │   │   ├── service/
│   │   │   │   ├── XoxlorezVpnService.java   — Android VpnService
│   │   │   │   └── PingService.java          — измерение пинга TCP
│   │   │   ├── ui/
│   │   │   │   ├── SplashActivity.java       — экран загрузки + первый пинг
│   │   │   │   ├── MainActivity.java         — главный экран (3 вкладки)
│   │   │   │   ├── RegionActivity.java       — список серверов
│   │   │   │   └── ServerAdapter.java        — адаптер RecyclerView
│   │   │   └── utils/ConfigManager.java      — менеджер конфигов
│   │   ├── assets/configs/                   — все серверные конфиги
│   │   │   ├── BYPASS
│   │   │   ├── CUSTOM
│   │   │   ├── STR
│   │   │   ├── STR.BYPASS
│   │   │   └── Vless
│   │   └── res/                              — ресурсы (layouts, drawables, colors)
│   └── build.gradle
└── settings.gradle
```

## Как собрать APK

### Метод 1 — Android Studio (рекомендуется)
1. Скачай **Android Studio** (https://developer.android.com/studio)
2. Открой папку `XoxlorezVPN` как проект
3. Дождись синхронизации Gradle
4. Нажми **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK будет в: `app/build/outputs/apk/debug/app-debug.apk`

### Метод 2 — Командная строка (Gradle)
```bash
cd XoxlorezVPN
chmod +x gradlew
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

### Требования
- Android Studio Hedgehog (2023.1.1) или новее
- JDK 17+
- Android SDK 34
- minSdk 26 (Android 8.0+)

## Протоколы
Поддерживаются все ваши конфиги:
- **VLESS** (TCP, WS, gRPC, xHTTP)
- **VLESS + XTLS-Reality**
- **VMess** (TCP, WS, TLS)
- **Shadowsocks** (AES, ChaCha20)
- **Trojan**
- **WireGuard**

## Функционал
- Первый запуск: авто-проверка всех серверов (ping)
- Повторный запуск: без проверки (быстрый старт)
- 3 вкладки: VPN | Настройки | Тема
- Выбор региона с флагами, пингом и протоколом
- Поиск по стране
- Таймер uptime
- Пульс-анимация при подключении
- 3 темы: Cyberpunk / Deep Dark / Neon Blue
